//
//  OrderPayCell.m
//  几何社区
//
//  Created by 颜 on 15/9/18.
//  Copyright (c) 2015年 lmh. All rights reserved.
//

#import "OrderPayCell.h"

@implementation OrderPayCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
