//
//  LmhTabBarController.h
//  几何社区
//
//  Created by KMING on 15/8/20.
//  Copyright © 2015年 lmh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShopCarViewController.h"

@interface LmhTabBarController : UITabBarController
@property (nonatomic,strong)ShopCarViewController *shopcar;
@end
