//
//  MiaoshaDetailModel.m
//  几何社区
//
//  Created by KMING on 15/10/13.
//  Copyright © 2015年 lmh. All rights reserved.
//

#import "MiaoshaDetailModel.h"

@implementation MiaoshaDetailModel

@end
