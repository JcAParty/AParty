//
//  CollectionReusableView.m
//  几何社区
//
//  Created by 颜 on 15/9/2.
//  Copyright (c) 2015年 lmh. All rights reserved.
//

#import "CollectionReusableView.h"

@implementation CollectionReusableView

- (void)awakeFromNib {
    // Initialization code
    _lblName.textColor = RGBCOLOR(154, 154, 154, 1);
}

@end
