//
//  MyCouponsFooterView.m
//  几何社区
//
//  Created by KMING on 15/9/23.
//  Copyright © 2015年 lmh. All rights reserved.
//

#import "MyCouponsFooterView.h"

@implementation MyCouponsFooterView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
