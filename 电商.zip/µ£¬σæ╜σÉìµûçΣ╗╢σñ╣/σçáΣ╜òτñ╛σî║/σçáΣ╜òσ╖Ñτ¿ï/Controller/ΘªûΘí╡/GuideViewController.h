//
//  GuideViewController.h
//  几何社区
//
//  Created by KMING on 15/9/28.
//  Copyright © 2015年 lmh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GuideViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIScrollView *myScroll;

@end
