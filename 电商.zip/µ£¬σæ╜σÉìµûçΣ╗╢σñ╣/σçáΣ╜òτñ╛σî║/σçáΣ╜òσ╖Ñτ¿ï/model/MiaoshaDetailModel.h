//
//  MiaoshaDetailModel.h
//  几何社区
//
//  Created by KMING on 15/10/13.
//  Copyright © 2015年 lmh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MiaoshaDetailModel : NSObject
@property (nonatomic,copy)NSString *capacity;
@property (nonatomic,copy)NSString *content;
@property (nonatomic,copy)NSString *discount_price;
@property (nonatomic,copy)NSString *flag;
@property (nonatomic,copy)NSString *flag_time;
@property (nonatomic,copy)NSString *imgsrc;
@property (nonatomic,copy)NSString *limit_amount;
@property (nonatomic,copy)NSString *mid;
@property (nonatomic,copy)NSString *pid;
@property (nonatomic,copy)NSString *remain_amount;
@property (nonatomic,copy)NSString *title;
@property (nonatomic,copy)NSString *type;
@property (nonatomic,copy)NSString *time;


@end
