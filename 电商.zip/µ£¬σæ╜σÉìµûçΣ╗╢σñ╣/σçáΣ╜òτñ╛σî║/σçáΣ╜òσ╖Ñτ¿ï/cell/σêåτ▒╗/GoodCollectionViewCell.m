//
//  GoodCollectionViewCell.m
//  几何社区
//
//  Created by 颜 on 15/9/2.
//  Copyright (c) 2015年 lmh. All rights reserved.
//

#import "GoodCollectionViewCell.h"

@implementation GoodCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
