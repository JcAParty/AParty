//
//  HomeClickActvityViewController.h
//  几何社区
//
//  Created by KMING on 15/9/10.
//  Copyright (c) 2015年 lmh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeClickActvityViewController : JHBasicViewController
@property (nonatomic,copy)NSString *url;//网址
@end
