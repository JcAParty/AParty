//
//  GoodDetailCell.h
//  几何社区
//
//  Created by 颜 on 15/9/2.
//  Copyright (c) 2015年 lmh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodDetailCell : UITableViewCell /*商品分类 右侧cell*/

@end
