//
//  MyOrderViewController.h
//  几何社区
//
//  Created by KMING on 15/8/27.
//  Copyright (c) 2015年 lmh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyOrderViewController : JHBasicViewController
@property(nonatomic,strong)UIScrollView *myscroll;
@property(nonatomic,strong)NSMutableArray* topBtnArr;//顶端按钮的数组
@end
