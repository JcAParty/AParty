//
//  SettingFirstTableViewCell.h
//  几何社区
//
//  Created by KMING on 15/8/22.
//  Copyright (c) 2015年 lmh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingFirstTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *touxiang;
@property (weak, nonatomic) IBOutlet UILabel *nickname;
@property (weak, nonatomic) IBOutlet UILabel *phonenum;

@end
