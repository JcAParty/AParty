//
//  AMapSearchError.h
//  AMapSearchKit
//
//  Created by xiaoming han on 15/7/29.
//  Copyright (c) 2015年 AutoNavi. All rights reserved.
//

#ifndef AMapSearchKit_AMapSearchError_h
#define AMapSearchKit_AMapSearchError_h

/** AMapSearch errorDomain */
extern NSString * const AMapSearchErrorDomain;

/** AMapSearch errorCode */
typedef NS_ENUM(NSInteger, AMapSearchErrorCode)
{
    AMapSearchErrorOK                       = 0, //!< 没有错误
    AMapSearchErrorUnknown                  = 1, //!< 未知错误
    AMapSearchErrorInvalidSCode             = 2, //!< 安全码验证错误
    AMapSearchErrorInvalidKey               = 3, //!< key非法或过期
    AMapSearchErrorInvalidService           = 4, //!< 请求服务不存在
    AMapSearchErrorInvalidResponse          = 5, //!< 请求服务响应错误
    AMapSearchErrorInsufficientPrivileges   = 6, //!< 无权限访问此服务
    AMapSearchErrorOverQuota                = 7, //!< 请求超出配额
    AMapSearchErrorInvalidParams            = 8, //!< 请求参数非法
    AMapSearchErrorInvalidProtocol          = 9, //!< 协议解析错误
    AMapSearchErrorKeyNotMatch              = 10, //!< 请求key与绑定平台不符
    AMapSearchErrorTooFrequently            = 11, //!< 用户访问过于频繁
    
    AMapSearchErrorInvalidUserID            = 30, //!< 找不到对应userID的信息
    AMapSearchErrorKeyNotBind               = 31, //!< key未开通“附近”功能，请到管理台完成绑定
    
    AMapSearchErrorTimeOut                  = 100, //!< 连接超时
    AMapSearchErrorCannotFindHost           = 101, //!< 找不到主机
    AMapSearchErrorBadURL                   = 102, //!< URL异常
    AMapSearchErrorNotConnectedToInternet   = 103, //!< 连接异常
    AMapSearchErrorCannotConnectToHost      = 104, //!< 服务器连接失败
};

#endif
