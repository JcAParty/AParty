//
//  HomeNewBannerFirstTableViewCell.h
//  几何社区
//
//  Created by KMING on 15/10/10.
//  Copyright © 2015年 lmh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeNewBannerFirstTableViewCell : UITableViewCell
@property (nonatomic,strong)UIImageView *imgV;
@end
