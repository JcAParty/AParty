//
//  MiaoShaDaojishiView.h
//  几何社区
//
//  Created by KMING on 15/10/14.
//  Copyright © 2015年 lmh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MiaoShaDaojishiView : UIView
@property (weak, nonatomic) IBOutlet UILabel *juliLbl;
@property (weak, nonatomic) IBOutlet UILabel *shiLbl;
@property (weak, nonatomic) IBOutlet UILabel *fenLbl;
@property (weak, nonatomic) IBOutlet UILabel *miaoLbl;

@end
