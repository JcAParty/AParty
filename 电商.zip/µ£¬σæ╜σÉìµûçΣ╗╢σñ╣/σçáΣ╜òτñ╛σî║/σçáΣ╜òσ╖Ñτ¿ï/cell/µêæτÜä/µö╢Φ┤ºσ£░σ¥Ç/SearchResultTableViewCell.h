//
//  SearchResultTableViewCell.h
//  几何社区
//
//  Created by KMING on 15/9/1.
//  Copyright (c) 2015年 lmh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchResultTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *namelabel;
@property (weak, nonatomic) IBOutlet UILabel *placeLabel;

@end
