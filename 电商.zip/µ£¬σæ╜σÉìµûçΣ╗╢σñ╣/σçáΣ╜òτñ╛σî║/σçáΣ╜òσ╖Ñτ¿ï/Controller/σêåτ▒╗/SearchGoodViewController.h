//
//  SearchGoodViewController.h
//  几何社区
//
//  Created by 颜 on 15/9/6.
//  Copyright (c) 2015年 lmh. All rights reserved.
//

#import "JHBasicViewController.h"

@interface SearchGoodViewController : JHBasicViewController
@property (nonatomic , strong) NSArray *hotSearchList;


@end
