//
//  MyorderProductModel.h
//  几何社区
//
//  Created by KMING on 15/9/21.
//  Copyright © 2015年 lmh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyorderProductModel : NSObject
@property (nonatomic,copy)NSString *iid;
@property (nonatomic,copy)NSString *model_id;
@property (nonatomic,copy)NSString *pic_url;
@property (nonatomic,copy)NSString *pic_url_origin;
@property (nonatomic,copy)NSString *price;
@property (nonatomic,copy)NSString *quantity;
@property (nonatomic,copy)NSString *shop_id;
@property (nonatomic,copy)NSString *title;
@property (nonatomic,copy)NSString *tookprice;
@property (nonatomic,copy)NSString *unit;//包、、、

@end
