//
//  ShareTableViewController.h
//  几何社区
//
//  Created by KMING on 15/9/25.
//  Copyright © 2015年 lmh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShareTableViewController : JHBasicTableViewController
@property (nonatomic)int sdkNum;

@end
